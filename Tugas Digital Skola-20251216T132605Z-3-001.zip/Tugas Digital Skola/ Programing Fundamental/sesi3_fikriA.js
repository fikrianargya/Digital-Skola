let segitiga = 4

for (i = 1; i <= segitiga; i++) {
    let baris = ""
for (let j = 1; j <= i; j++) {
    baris += "*"
  }
    console.log(baris)
}
